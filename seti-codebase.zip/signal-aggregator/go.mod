module github.com/Pelentan/tca-seti/signal-aggregator

go 1.22

require github.com/redis/go-redis/v9 v9.5.1

require (
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/dgryski/go-rendezvous v0.0.0-20200823014737-9f7001d12a5f // indirect
)
